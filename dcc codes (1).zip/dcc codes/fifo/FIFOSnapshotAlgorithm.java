import java.util.ArrayList;
import java.util.List;

class Process {
    private final int processId;
    private final int numProcesses;
    private final List<Message> incomingMessages;
    private final List<Message> outgoingMessages;
    private final int[] vectorClock;
    private final List<String> localState;

    public Process(int processId, int numProcesses) {
        this.processId = processId;
        this.numProcesses = numProcesses;
        this.incomingMessages = new ArrayList<>();
        this.outgoingMessages = new ArrayList<>();
        this.vectorClock = new int[numProcesses];
        this.localState = new ArrayList<>();
    }

    public void send(Message message) {
        outgoingMessages.add(message);
    }

    public void receive(Message message) {
        incomingMessages.add(message);
    }

    public void initiateSnapshot() {
        localState.add("Started snapshot");
        Marker marker = new Marker(processId, vectorClock);
        send(marker);
    }

    public void recordLocalState() {
        localState.add("Recorded local state");
    }

    public void processMessages() {
        while (!incomingMessages.isEmpty()) {
            Message message = incomingMessages.remove(0);
            updateVectorClock(message.getVectorClock());
            localState.add("Received message: " + message.getContent());
        }
    }

    private void updateVectorClock(int[] receivedClock) {
        for (int i = 0; i < vectorClock.length; i++) {
            vectorClock[i] = Math.max(vectorClock[i], receivedClock[i]);
        }
        vectorClock[processId]++;
    }

    public List<String> getLocalState() {
        return localState;
    }

    public List<Message> getOutgoingMessages() {
        return outgoingMessages;
    }

    public int getProcessId() {
        return processId;
    }
}

class Message {
    private final int senderId;
    private final String content;
    private final int[] vectorClock;

    public Message(int senderId, String content, int[] vectorClock) {
        this.senderId = senderId;
        this.content = content;
        this.vectorClock = vectorClock.clone();
    }

    public int getSenderId() {
        return senderId;
    }

    public String getContent() {
        return content;
    }

    public int[] getVectorClock() {
        return vectorClock.clone();
    }
}

class Marker extends Message {
    public Marker(int senderId, int[] vectorClock) {
        super(senderId, "Marker", vectorClock);
    }
}

public class FIFOSnapshotAlgorithm {
    public static void main(String[] args) {
        int numProcesses = 3;
        Process[] processes = new Process[numProcesses];

        // Initialize processes
        for (int i = 0; i < numProcesses; i++) {
            processes[i] = new Process(i, numProcesses);
        }

        // Simulate message passing and snapshot
        processes[0].initiateSnapshot();

        // Simulate further message passing and snapshot recording
        for (Process process : processes) {
            process.processMessages();
            process.recordLocalState();
            for (Message message : process.getOutgoingMessages()) {
                processes[message.getSenderId()].receive(message);
            }
        }

        // Print global state
        printGlobalState(processes);
    }

    private static void printGlobalState(Process[] processes) {
        System.out.println("Global state:");
        for (Process process : processes) {
            System.out.println("Process " + process.getProcessId() + " state: " + process.getLocalState());
        }
    }
}
