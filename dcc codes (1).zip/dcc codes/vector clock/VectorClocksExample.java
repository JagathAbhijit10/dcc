import java.util.Arrays;
public class VectorClocksExample {
public static void main(String[] args) {
// Create and initialize vector clocks for 3 processes
int numberOfProcesses = 3;
VectorClock[] clocks = new VectorClock[numberOfProcesses];
for (int i = 0; i < numberOfProcesses; i++) {
clocks[i] = new VectorClock(numberOfProcesses, i);


}

// Simulate message sending and receiving
sendMessage(clocks[0], clocks[1]); // Process 0 sends a message to Process 1
sendMessage(clocks[1], clocks[2]); // Process 1 sends a message to Process 2
sendMessage(clocks[2], clocks[0]); // Process 2 sends a message to Process 0

// Print final state of vector clocks
for (int i = 0; i < numberOfProcesses; i++) {
System.out.println("Clock of Process " + i + ": " + clocks[i]);
}
}

private static void sendMessage(VectorClock sender, VectorClock receiver) {
sender.increment();
VectorClock messageClock = new VectorClock(sender);
receiver.receive(messageClock);
}

static class VectorClock {
private int[] clock;
private int processId;

public VectorClock(int size, int processId) {
this.clock = new int[size];
this.processId = processId;
}

public VectorClock(VectorClock other) {
this.clock = Arrays.copyOf(other.clock, other.clock.length);
this.processId = other.processId;
}

public void increment() {


clock[processId]++;
}

public void receive(VectorClock messageClock) {
for (int i = 0; i < clock.length; i++) {
clock[i] = Math.max(clock[i], messageClock.clock[i]);
}
}

@Override
public String toString() {
return Arrays.toString(clock);
}
}
}