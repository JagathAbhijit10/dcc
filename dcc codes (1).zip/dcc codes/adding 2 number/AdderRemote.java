import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class AdderRemote extends UnicastRemoteObject implements Adder {
AdderRemote() throws RemoteException {
super();
}
public int add(int x, int y)
{
return x + y;

}

public static void main(String args[]) {
try {
Adder stub = new AdderRemote();
Naming.rebind("rmi://localhost:5000/AdderService", stub);
} catch (Exception e) {
System.err.println("Server exception: " + e.toString());
e.printStackTrace();
}
}
}